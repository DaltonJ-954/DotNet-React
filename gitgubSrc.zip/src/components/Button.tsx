export default function Button({ onClick, children, disabled, type, className }: React.PropsWithChildren<ButtonProps>) {
    return (
        <button
        onClick={ onClick }
        disabled={ disabled ?? false }
        type={ type ?? 'button' }
        className={ className }
    >
        { children }
    </button>
    )
}

interface ButtonProps {
    children?: React.ReactNode;
    onClick?: () => void;
    type?: 'button' | 'submit';
    disabled?: boolean
    className?: string;
}