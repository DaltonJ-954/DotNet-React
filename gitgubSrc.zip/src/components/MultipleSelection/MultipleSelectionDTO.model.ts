export default interface MultipleSelectionDTO {
    key: number;
    description: string;
}