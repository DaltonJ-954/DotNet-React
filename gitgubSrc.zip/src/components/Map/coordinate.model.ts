export default interface Coordinate {
    lng: number;
    lat: number;
    message?: string;
}