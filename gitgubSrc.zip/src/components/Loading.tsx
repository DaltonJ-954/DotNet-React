import loading from './../assets/loading.gif';

export default function Loading() {
    return <img style={{"width": "300px", "height": "230px"}} alt='Loading' src={loading} />
}