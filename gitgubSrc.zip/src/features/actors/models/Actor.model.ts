export default interface Actor {
    id: number;
    name: string;
    dateOfBirth: string;
    picture: string;
}