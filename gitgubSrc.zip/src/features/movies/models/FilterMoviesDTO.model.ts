export default interface FilterMoviesDTO {
    title: string;
    genreId: number;
    upcomingReleases: boolean;
    inTheaters: boolean;
}