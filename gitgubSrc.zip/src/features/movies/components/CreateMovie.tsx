import type { SubmitHandler } from "react-hook-form"
import type MovieCreation from "../models/MovieCreation.model"
import MovieForm from "./MovieForm";
import type Genre from "../../genres/models/Genre.model";
import type Theater from "../../theaters/models/Theater.model";

export default function CreateMovie() {

    const onSubmit: SubmitHandler<MovieCreation> = async (data) => {
        await new Promise(resolve => setTimeout(resolve, 2000));
        console.log(data)
    }

    const nonSelectedGenres: Genre[] = [{ id: 1, name: 'Action' }, { id: 2, name: 'Sci-Fi' }, { id: 3, name: "Comedy" }, 
        { id: 4, name: "Fantasy" }, { id: 5, name: "Drama" }, { id: 6, name: "Suspense" }, { id: 7, name: 'Horror' }, 
        { id: 8, name: 'Thriller' }, { id: 9, name: 'Romance' }, { id: 10, name: 'Western' }, { id: 11, name: 'Mystery' }]

    const nonSelectedTheaters: Theater[] = [{ id: 1, name: 'Cinamark Bistro', latitude: 0, Longitude: 0 },
        { id: 2, name: 'Reagal Pompano', latitude: 0, Longitude: 0 }, 
        { id: 3, name: 'AMC Dine-In', latitude: 0, Longitude: 0 }, { id: 4, name: 'Regal Broward', latitude: 0, Longitude: 0 }
    ]

    return (
        <>
            <h3>Create Movie</h3>
            <MovieForm onSubmit={ onSubmit } nonSelectedGenres={ nonSelectedGenres } 
            selectedGenres={ [] }
            nonSelectedTheaters={ nonSelectedTheaters }
            selectedTheaters={ [] }
            selectedActors={ [] }
            />
        </>
    )
}