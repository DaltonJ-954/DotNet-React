import type Movie from "../../movies/models/movie.model";

export default interface LandingPageDTO {
    InTheaters? : Movie[];
    UpcomingReleases? : Movie[];
}