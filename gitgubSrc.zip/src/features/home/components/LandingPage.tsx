import { useState, useEffect } from "react";
import MoviesList from "../../movies/components/MoviesList";
import type Movie from "../../movies/models/movie.model";
import type LandingPageDTO from "./LandingPageDTO";

export default function LandingPage() {

    const [movies, setMovies] = useState<LandingPageDTO>({})

  useEffect(() => {
    const inTheaters: Movie[] = [
    {
      id: 1,
      title: "Dune",
      poster: "https://tse2.mm.bing.net/th/id/OIP.GURNPPODfsKPHH6kkKqBRAHaLH?cb=ucfimg2&ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3"
    },
    {
      id: 2,
      title: "Interstellar",
      poster: "https://th.bing.com/th/id/OIP.jtA_UQXkZ0d4eQqj7ghF_AHaLH?w=189&h=284&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    },
    {
      id: 3,
      title: "Avengers Endgame",
      poster: "https://th.bing.com/th/id/OIP.NPe2_emQ2NnSqxdh6Lw1EwHaK0?w=189&h=277&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    },
    {
      id: 4,
      title: "The Dark Knight",
      poster: "https://th.bing.com/th/id/OIP.EiYWDhI6ftiJWGU9SFb_2wHaLH?w=189&h=284&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    },
    {
      id: 5,
      title: "Mario: The Movie",
      poster: "https://th.bing.com/th/id/OIP.WjiZcayuXkOX6nXAYtFCtQHaLu?w=189&h=300&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    }
  ]

  const upcomingReleases: Movie[] = [
    {
      id: 6,
      title: "The Mandalorian & Grogu",
      poster: "https://www.starwarsnewsnet.com/wp-content/uploads/2023/02/Mandalorian-S3-character-poster-Din-and-Grogu.jpg"
    },
    {
      id: 7,
      title: "Avatar 3",
      poster: "https://th.bing.com/th/id/OIP.yaSN_Dr11kV53f4EhEk_HQHaLH?w=189&h=284&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    },
    {
      id: 8,
      title: "Mercy",
      poster: "https://th.bing.com/th/id/OIP.A2S0GVtERf43ndr8D_et0QHaK-?w=189&h=280&c=7&r=0&o=7&cb=ucfimg2&dpr=1.5&pid=1.7&rm=3&ucfimg=1"
    }
  ]

  setTimeout(() => {
    setMovies({
      InTheaters: inTheaters,
      UpcomingReleases: upcomingReleases
    })
  }, 700);
  }, [])

    return (
        <>
            <h3>In Theaters</h3>
                  <MoviesList movies={movies.InTheaters} />,
            
                  <h3>Upcoming Releases</h3>
                  <MoviesList movies={movies.UpcomingReleases} />
        </>
    )
}