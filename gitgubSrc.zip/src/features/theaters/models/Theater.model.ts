export default interface Theater {
    id: number;
    name: string;
    latitude: number;
    Longitude: number;
}