import { useEffect, useState } from "react";
import { useParams } from "react-router"
import type TheaterCreation from "../models/TheaterCreations";
import Loading from "../../../components/Loading";
import TheaterForm from "./TheaterForm";
import type { SubmitHandler } from "react-hook-form";

export default function EditTheater() {

    const {id} = useParams();
    const [model, setModel] = useState<TheaterCreation | undefined>(undefined);

    useEffect(() => {
        const timerId = setTimeout(() => {
            setModel({ name: 'Dune ' + id, latitude: 26.377164134372325, longitude: 80.1132801175254 });
        }, 1000);

        return () => clearTimeout(timerId)
    }, [id])

    const onSubmit: SubmitHandler<TheaterCreation> = async (data) => {
            await new Promise(resolve => setTimeout(resolve, 1000));
            console.log(data)
        }

    return(
        <>
            <h3>Edit Theater</h3>
            { model ? <TheaterForm model={ model } onSubmit={ onSubmit } /> : <Loading /> }
        </>
    )
}