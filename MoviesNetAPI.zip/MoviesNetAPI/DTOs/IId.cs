﻿namespace MoviesNetAPI.DTOs
{
    public interface IId
    {
        public int Id { get; set; }
    }
}
