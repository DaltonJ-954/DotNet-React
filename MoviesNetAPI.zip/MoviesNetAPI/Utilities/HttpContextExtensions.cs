﻿using Microsoft.EntityFrameworkCore;

namespace MoviesNetAPI.Utilities
{
    public static class HttpContextExtensions
    {
        public async static Task InsertPaginationParaInHeader<T>(this HttpContext httpContext,
            IQueryable<T> queryable)
        {
            if (httpContext is null)
            {
                ArgumentNullException.ThrowIfNull(httpContext);
            }

            double totalRecords = await queryable.CountAsync();
            httpContext.Response.Headers.Append("Total-Records", totalRecords.ToString());
        }
    }
}
