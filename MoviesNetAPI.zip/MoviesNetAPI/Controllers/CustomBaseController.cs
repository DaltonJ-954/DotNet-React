﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MoviesNetAPI.DTOs;
using MoviesNetAPI.Utilities;
using System.Formats.Tar;
using System.Linq.Expressions;

namespace MoviesNetAPI.Controllers
{
    public class CustomBaseController : ControllerBase
    {
        private readonly ApplicationDbContext context;
        private readonly IMapper mapper;

        public CustomBaseController(ApplicationDbContext context, IMapper mapper)
        {
            this.context = context;
            this.mapper = mapper;
        }

        protected async Task<List<TDTO>> Get<TEntity, TDTO>(PaginationDTO pagination,
            Expression<Func<TEntity, object>> orderBy)
            where TEntity: class
        {
            var queryable = context.Set<TEntity>().AsQueryable();
            await HttpContext.InsertPaginationParaInHeader(queryable);
            return await queryable
                .OrderBy(orderBy)
                .Paginate(pagination)
                .ProjectTo<TDTO>(mapper.ConfigurationProvider)
                .ToListAsync();

        }
    }
}
